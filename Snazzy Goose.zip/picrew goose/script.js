var img = new Image();

function changeImg(imagePath, imageCanvas) {
    var canvas = document.getElementById(imageCanvas);
    var ctx = canvas.getContext('2d');
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    img.onload = function(){
          ctx.drawImage(img,0,0);
    };
    img.src = imagePath;
}



//Containers
const bodyBtnCont = document.getElementById("body-menu");
const eyeBtnCont = document.getElementById("eye-menu");
const beakBtnCont = document.getElementById("beak-menu");
const accessUnderBtnCont = document.getElementById("accessories-under-menu")
const accessOverBtnCont1 = document.getElementById("accessories-over-menu-1")
const accessOverBtnCont2 = document.getElementById("accessories-over-menu-2")
const accessOverBtnCont3 = document.getElementById("accessories-over-menu-3")
const feetBtnCont = document.getElementById("feet-menu");
const wingBtnCont = document.getElementById("wing-menu");
const bgBtnCont = document.getElementById("background-menu");

//Arrays
const bodies = [
  { name: "white", file: "body/basic.png"},
  { name: "brown", file: "body/brown.png"}
];

const wings = [
  {name: "white", file: "wing/basic.png"},
  { name: "brown", file: "wing/brown.png"}

]
const feet = [
  { name: "yellow", file: "feet/basic.png" },
  { name: "gray", file: "feet/gray.png" }
];

const eyes = [
  { name: "basic", file: "eyes/basic.png" }
];

const beaks = [
  { name: "yellow", file: "beak/basic.png" },
  { name: "gray", file: "beak/gray.png" }
  ];

const access_under = [
  { name: "none", file: "empty.png"},
  { name: "knife", file: "acessories_under/knife.png"},
  { name: "flower", file: "acessories_under/flower.png"}
]

const access_over = [
  { name: "none", file: "empty.png"},
  { name: "tophat", file: "acessories_over/tophat.png"},
  { name: "wizard hat", file: "acessories_over/wizard_hat.png"}, 
  { name: "monocle", file: "acessories_over/monocle.png"},
  { name: "mustache", file: "acessories_over/mustache.png"}
]

const backgrounds = [
  { name: "none", file: "empty.png"},
  { name: "plain", file: "bg/plain.png"},
  { name: "grass", file: "bg/grass.png"},
  { name: "leaves", file: "bg/leaves.png"},
  { name: "falling leaves", file: "bg/falling leaves.png"},
  { name: "blood splatter", file: "bg/blood splatter.png"},
  { name: "sparkles", file: "bg/sparkles.png"},
  { name: "pink feathers", file: "bg/pink feathers.png"},
  { name: "dappled light", file: "bg/dappled light.png"},
  { name: "flowers", file: "bg/flowers.png"},
  { name: "night sky", file: "bg/night sky.png"},
  { name: "pride flag", file: "bg/pride flag.png"},
  { name: "trans flag", file: "bg/trans flag.png"},

]

const menus = [
  { title: "Bodies", array: bodies, container: bodyBtnCont, canvas: "body-canvas"},
  { title: "Wings ", array: wings, container: wingBtnCont,  canvas: "wing-canvas" },
  { title: "Feet", array: feet, container: feetBtnCont,  canvas: "feet-canvas" },
  { title: "Eyes", array: eyes, container: eyeBtnCont,  canvas: "eye-canvas" },
  { title: "Beaks", array: beaks, container: beakBtnCont, canvas: "beak-canvas" },
  { title: "Accesories (under)", array: access_under, container: accessUnderBtnCont, canvas: "accessories-under-canvas" },
  { title: "Accesories 1 (over)", array: access_over, container: accessOverBtnCont1, canvas: "accessories-over-canvas-1" },
  { title: "Accesories 2 (over)", array: access_over, container: accessOverBtnCont2, canvas: "accessories-over-canvas-2" },
  { title: "Accesories 3 (over)", array: access_over, container: accessOverBtnCont3, canvas: "accessories-over-canvas-3" },
  { title: "Backgrounds", array: backgrounds, container: bgBtnCont, canvas: "background-canvas"}
]

menus.forEach(menu => {
  menu.array.forEach(item => {
    let btn = document.createElement("button");
    btn.textContent = item.name;

    btn.onclick = () => changeImg(item.file, menu.canvas);
    menu.container.appendChild(btn);
  });
});

function openMenu(evt, menuName) {
    var i, tabcontent, tablinks;
  
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    document.getElementById(menuName).style.display = "block";
    evt.currentTarget.className += " active";
  }


  //Canvases
const bodyCanvas = document.getElementById("body-canvas");
const eyeCanvas = document.getElementById("eye-canvas");
const beakCanvas = document.getElementById("beak-canvas");
const accesUnderCanvas = document.getElementById("accessories-under-canvas");
const accesOverCanvas1 = document.getElementById("accessories-over-canvas-1");
const accesOverCanvas2 = document.getElementById("accessories-over-canvas-2");
const accesOverCanvas3 = document.getElementById("accessories-over-canvas-3");
const wingCanvas = document.getElementById("wing-canvas");
const feetCanvas = document.getElementById("feet-canvas");
const bgCanvas = document.getElementById("background-canvas");



const canvases = [bgCanvas, bodyCanvas, wingCanvas, feetCanvas, eyeCanvas, beakCanvas, accesUnderCanvas, accesOverCanvas1, accesOverCanvas2, accesOverCanvas3]; 

const combinedCanvas = document.createElement('canvas');
const combCtx = combinedCanvas.getContext('2d');

combinedCanvas.width = bodyCanvas.width; 
combinedCanvas.height = bodyCanvas.height;

function mergeCanvases(){
  canvases.forEach((canvas, index) => {
    combCtx.drawImage(canvas, 0, 0);
});
}


function exportCanvasAsImage() {
  mergeCanvases();

  const imageData = combinedCanvas.toDataURL('image/png'); 
  const link = document.createElement('a');
  link.href = imageData;
  link.download = 'goose.png';  
  link.click(); 
  combCtx.clearRect(0, 0, combinedCanvas.width, combinedCanvas.height); 
}



//TEST
/*** const canvas = document.getElementById("myCanvas");
  const ctx = canvas.getContext("2d");
  
  const img = new Image();
  img.src = "moose.png"; // Your shape image
  img.onload = () => {
    drawMaskedImage("blue"); // Default color on load
  };  */

  /*** 


function drawImageWithOverlay(color) {
  var canvas = document.getElementById(lastImageCanvas);
  var ctx = canvas.getContext('2d');

  ctx.clearRect(0, 0, canvas.width, canvas.height); // Clear previous frame
  
  // Draw the base image
  ctx.globalCompositeOperation = "source-over";
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  
  // Create a clipping path from the image's alpha channel
  let imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  let data = imageData.data;

  ctx.beginPath();
  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      let alpha = data[(y * canvas.width + x) * 4 + 3]; // Get alpha value
      if (alpha > 0) ctx.lineTo(x, y); // Only include non-transparent pixels
    }
  }
  ctx.closePath();
  ctx.clip(); // Apply clipping to non-transparent pixels

  // Overlay the color **inside the clipped area only**
  ctx.fillStyle = color;
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "multiply"; 
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Reset blend mode and clipping
  ctx.globalCompositeOperation = "source-over";
  ctx.restore();
}

// Function to change the color dynamically
function changeCanvasColor(hexColor) {
  let rgbaColor = hexToRGBA(hexColor, 0.5); // Convert hex to RGBA with opacity
  drawImageWithOverlay(rgbaColor);
}

// Convert HEX to RGBA
function hexToRGBA(hex, alpha) {
  let r = parseInt(hex.substring(1, 3), 16);
  let g = parseInt(hex.substring(3, 5), 16);
  let b = parseInt(hex.substring(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
 */